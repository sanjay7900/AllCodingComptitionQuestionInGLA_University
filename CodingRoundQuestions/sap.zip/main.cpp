/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class A
{
public:

A()
{
    cout << "1";
}
virtual ~A()
{
    cout<<"2";
}
};
class B: public A
{
public:
B()

{ 
    cout<<"3";
    
}

~B()
{
    cout <<"4";
    
}


};

int main()
{
    cout<<"Hello World";
   A *ptr=new B[2];
   delete [] ptr;
    return 0;
}
