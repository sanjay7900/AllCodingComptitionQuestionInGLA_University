/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
void maximam(int arr[],int k)
{
    int max=0;
    for(int i=1;i<k;++i)
    {
        if(arr[i]>max)
        {
            max=arr[i];
            cout<<max;
            max=0;
        }
        if(i%k==0&&k<=7)
        {
            k+=k;
            cout<<"i= "<<i;
        }
    }
}

int main()
{
    cout<<"Hello World";
    int arr[]={2,5,2,8,56,45,32,};
    maximam(arr,3);
    return 0;
}
