/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
#include<vector>

int main()
{ int e,n;
vector<int> g[1000];
    cout<<"Hello World";
    for(int i=1;i<=3;i++)
    { 
        cin>>n>>e;
        g[n].push_back(e);
    }
    for(int i=1;i<=3;i++){
        
    cout<<"sanjay it is next \n";
    for(int x:g[i]){
        cout<<endl<<x<<endl;
    }
    }
    return 0;
}
