/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
void findthe_missing_number_in_an_array(int arr[],int size,int up,int to){
    int a[10];
    int t,i,j,r,c=0;
    float m;
    for(i=up;i<=to;i++)
    {
        t=1;
        for(j=0;j<size;j++)
        {
           
            m=arr[j];
            m=float(m/i);
            if(m==1)
            {
           
                t=0;
              
            }
           
        }
        if(t==1)
        {
            
            a[c]=i;
            c++;
        }
    }
    
   for(i=0;i<c;i++){
        cout<<a[i]<<"  ";
   }
}

int main()
{
    cout<<"Hello World";
    int s;
    int arr[]={23,4,5,78,98,10,3};
    s=7;
    findthe_missing_number_in_an_array(arr,s,1,10);
    

    //return 0;
}





