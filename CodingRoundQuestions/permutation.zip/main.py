'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
print ('Hello World')
def all_permutation(n,s):
    l=list(s)
    fact=1
    main=[]
    for i in range(1,n+1):
        fact=fact*i
   # print(fact)  
    for i in range(0,len(l)):
        
        for j in range(0,len(l)):
            for k in range(4,0,-1):
                if k==j:
                    
                    pass
                else:
                    temp=l[k]
                    l[k]=l[j]
                    l[j]=temp
                    print(l)
                    if l not in main:
                        
                    
                        main.append(l)
                       
           
    print(len(main),main)       
           
all_permutation(5,"world")    
    