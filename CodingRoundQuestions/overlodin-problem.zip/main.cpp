/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/



#include<iostream>  
using namespace std;  
//void fun(int);  
void fun(int,int);  
/*void fun(int i)  
{  
    std::cout << "Value of i is : " <<i<< std::endl;  
}  */
void fun(int a,int b=9)  
{  
    std::cout << "Value of a is : " <<a<< std::endl;  
    std::cout << "Value of b is : " <<b<< std::endl;  
}  
int main()  
{  
    fun(12);  
   
    return 0;  
}  
