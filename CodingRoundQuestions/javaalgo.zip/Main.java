/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class kadanes{
    int l,m,n,o,p,q;
    kadanes(int arr[]){
        for(i=0;i<s;i++){
            if((arr[i]-arr[i+1])==1){
                max=arr[i]+max[i+1];
                max=max+arr[i+1];
                i++;
            }
            
        }
        if()
        
    }
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}
