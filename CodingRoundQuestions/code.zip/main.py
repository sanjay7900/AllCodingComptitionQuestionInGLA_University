'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def sa(n,k):
    s=set(n)
    l=list(s)
    c=0
    for i in range(len(l)):
        if l[i]+k in s:
            c+=1
            
    return c        
    
print ('Hello World')
l=[1,2,1,3,3]
a=set(l)
print(sa(l,1))
x=0
for i in range(0,10000000):
    x=x+1
print(x)    