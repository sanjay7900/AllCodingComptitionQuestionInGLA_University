/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Node{
    int data;
    Node left;
    Node right;
}
class bst{
    public Node cretenewnode(int val){
        Node a=new Node();
        a.left=null;
        a.right=null;
        a.data=val;
        return a;
        
    }
    public Node insertdata(Node root,int k)
    {
        if(root==null){
             return cretenewnode(k);
        }
        if(root.data>k)
        {
            root.left=insertdata(root.left,k);
        }
        else if(root.data<k){
            root.right=iinsertdata(root.right,k);
        }
        return root;
    }
}
public class Main
{
	public static void main(String[] args) {
		
		//System.out.println("Hello World");
		bst a=new bst();
		Node root=null;
		root=insertdata(4);
	}
}

