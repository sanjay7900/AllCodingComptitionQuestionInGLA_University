/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;
int bobble_sort(int arr[] ,int i,int n,int in)
{
    if(in>n)
    {
        return 0;
        
    }
    else
    {
        if(arr[i]>arr[in])
        {
            int temp=arr[in];
            arr[in]=arr[i];
            arr[i]=temp;
            
        }
        bobble_sort(arr,i,n,in+1);
    }
    
}
using namespace std;

int main()
{ int arr[6]={10,6,9,4,8,2};
int n=5;

    cout<<"Hello World\n";
    for(int i=0;i<=n;i++){
        int in=i+1;
        bobble_sort(arr,i,n,in);
    }
    for(int i=0;i<=n;i++)
    {
        cout<<" "<<arr[i];
    }

    return 0;
}

