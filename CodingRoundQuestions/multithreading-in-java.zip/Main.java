/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class threading extends Thread{
	public void run(){
           for(int i=0;i<=10;i++){
			   System.out.println("thread one "+i+"="+ Thread.currentThread().getId() );
			   
		   }
	  }
}
class threadingg extends Thread{

	
	public void run(){
		 
		
		for(int i=0;i<10;i++){
						   System.out.println("thread two "+i+"="+ Thread.currentThread().getId() );

	
		}
	}
	
	
		
    
}
			
		
		

		
public class Main
{
public static void main(String sanjay[]){
		threading b1=new threading();
		threadingg b2=new threadingg();
		
		
		b1.start();
		b2.start();
		//b2.st();
	}
}
