/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int
first_duplicate_number (int arr[], int size)
{
  int i, f, j, first_duplcate = size, temp = 1;
  for (j = 0; j < size - 1; j++)
    {

      for (i = size - 1; i > j; i--)
	{


	  if (arr[j] == arr[i])
	    {



	      if (((i - j - 1) < first_duplcate))
		{
		  first_duplcate = ((i - j) - 1);
		  f = first_duplcate;
		  f = f + j + 1;
		  // or
		  // these are logic are the best
		  //f=j;

		}


	    }

	}
    }
  //9675346359


  return f;
}





int
main ()
{
  int arr[] = { -9, 1, 7, 5, 54, 3, 36, 0, 8, -5, -3, 4, 6, -9 };
  int size = 14;
  int c;
  c = first_duplicate_number (arr, size);

  cout << arr[c];


  return 0;
}
