/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
int miss(int arr[],int i,int j,int n){
    if (j>=n){
       return 1;
    }
    if(i==arr[j]){
        cout<<"ys";
            return 0;
        }
        
    
    
   if (i!=arr[j]){
       cout<<"in ";
            miss(arr,i,j+1,n);
            return 1;
        
        }
        
    //{23,4,5,78,98,10,3}
}
int find(int arr[], int n,int up,int to)
{
    int c=0,m=0,j=0;
    int mis[n];
    for(int i=up;i<=to;i++){
        m=miss(arr,i,j,n);
        cout<<m;
        if(m){
            mis[j]=i;
            j++;
        }
        
        
        
    }
    for(int i=0;i<j;i++){
        cout<<mis[i]<<"  ";
   }
    
}
int main()
{
    printf("Hello World\n");
     int arr[]={23,4,5,78,98,10,3};
    int s=7;
    find(arr,s,1,10);
    return 0;
}

