/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int callbfs(int islandarr[],int i, int visited[])
{
    if(islandarr[i]==1)
    {
        visited[i] =1;
        callbfs(islandarr,i+1,visited);
        callbfs(islandarr,i+3,visited);
        return *visited;
    }
    else{
        return 0;
    }
}


int island(int islandarr[],int visited[])
{ int count=0;
    for(int i=1;i<=9;i++)
    { 
        
        if((islandarr[i]==1 && visited[i]!=1))
        {
            count++;
            *visited=callbfs(islandarr,i,visited);
        }
                
    }
    return count;
}

int main()
{
    int insert=1;
    cout<<"Hello World";
    int arr[3][3];
    int islandarr[9];
    int visited[9];
    for(int i=1;i<=3;i++)
    {
        for(int j =1;j<=3;j++)
        {
            cin>>arr[i][j];
            
        }
    }
    for(int i=1;i<=3;i++)
    {
        for(int j =1;j<=3;j++)
        {
            cout<<arr[i][j]<<" ";
            islandarr[insert]=arr[i][j];
            insert++;
            
            
        }
        cout<<"\n";
    }
    int c=island(islandarr,visited);
    cout<<"\n"<<c;
    return 0;
}




