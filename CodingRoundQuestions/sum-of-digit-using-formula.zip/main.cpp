/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int sum_of_digit(int number)
{
    int sum ;
    sum=(number*(number+1))/2;
    return sum;
    
}

int main()
{
    cout<<"Hello World";
    int sum;
    sum=sum_of_digit(5);
    cout<<"\n"<<sum;

    return 0;
}
