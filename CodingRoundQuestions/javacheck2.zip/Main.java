/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	//	int a= new int[10];
	int i,sum=0,j=0;
	int a[]={1,2,-3,5,6,7,8,9,-10,-9,-8,-3};
		for(i=0;i<8;i++){
		    if((a[i+1]-a[i])==1){
		        
		        sum=sum+a[i]+a[i+1];
		        if(j>=1){
		        sum=sum-a[i];
		        }
		        j++;
		        //i++;
		    }
		    else{
		        sum=0;
		        j=0;
		    }
		    System.out.println(sum);
		    
		}
	}
}
