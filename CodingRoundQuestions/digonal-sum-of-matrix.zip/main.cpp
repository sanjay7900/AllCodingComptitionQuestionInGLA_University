/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int digonal_sum(int arr[3][3],int size)
{
    int i,j,k=0;
     for(i=0;i<size;i++)
     {
          for(j=0;j<size;j++)
          {
              cout<<arr[i][j]<<" ";
          }
          cout<<"\n";
     }
    for(i=0;i<size;i++)
    {
    
            k=k+arr[i][i];
            
       
    }
    
    return k;
}

int main()
{
    cout<<"Hello World";
    int arr[3][3];
    int i,j,k,size=3;
     for(i=0;i<size;i++)
     {
          for(j=0;j<size;j++)
          {
              cin>>arr[i][j];
              cout<<" ";
          }
          cout<<"\n";
     }
    k= digonal_sum(arr,size);
    cout<<"\n"<<k;

    return 0;
}
