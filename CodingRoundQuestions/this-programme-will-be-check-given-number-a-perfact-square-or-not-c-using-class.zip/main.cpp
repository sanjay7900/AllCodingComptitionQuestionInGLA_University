/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class perfect_square{
    int i=0, j , sum=0, n;
    public:
    perfect_square(int m){
        n=m;
    }
    void square_ckeck();
};


 void perfect_square::square_ckeck()
 {
     while(sum<n)
     {
         i++;
         sum=i*i;
         
     }
     
     if(i*i==n)
     {
         cout<<"this number is perfact square = "<<i;
     }
     else
     {
         cout<<"\nnot"<<i;
     }
     
 }

int main()
{ 
    int l,n;
    cout<<"Hello World\n";
    while(l!=1)
    {
        cout<<"\nenter the number::";
        cin>>n;
        perfect_square a1(n);
        a1.square_ckeck();
        cout<<"\nenter the choice";
        cin>>l;
    }

    return 0;
}
