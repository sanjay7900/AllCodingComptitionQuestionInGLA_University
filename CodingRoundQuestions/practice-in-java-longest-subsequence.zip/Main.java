/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class longest
{
    int i,j,l;
   // int[] arr=new int[];
    void find_subsequnce(int array[],int n)
    {
      int[] arr=new int[]{-1,-1,-1,-1,-1}; 
       
      
      
      for(i=0;i<n-1;i++)
      {
          if(array[i]>array[i+1])
          {
              arr[i]=i;
             // System.out.println("\n"+array[arr[i]]);
              
          }
          
      }
      for(i=0;i<n;i++)
      {
          //System.out.println("\n"+array[i]);
          if(arr[i]==-1)
          {
              
          }
          else
          {
            System.out.println("\n"+array[arr[i]]);  
          }
      }
      
    }

}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int[] array=new int[]{3, 10, 2, 1, 20};
		int n=5;
		
		longest a1=new longest();
		a1.find_subsequnce(array,n);
	}
}
