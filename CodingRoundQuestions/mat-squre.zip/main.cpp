/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int maximal_square(int (*arr)[3])
{
    int i,j,sum=0,sq=0;
    for(i=0;i<3;++i)
    {
        for(j=0;j<3;++j)
        {
            if(*(*(arr+i)+j)==*(*(arr+j)+i)&&*(*(arr+j)+j))
            {
                sq+=1;
            }
            
        }
    }
    
    return sq-3;
    
}

int main()
{
    cout<<"Hello World";
    int arr[3][3];
    for(int i=0;i<3;++i)
    {
        for(int j=0;j<3;++j)
        {
            cin>>arr[i][j];
            
        }
        cout<<"\n";
        
    }
    cout<<maximal_square(arr);

    return 0;
}
