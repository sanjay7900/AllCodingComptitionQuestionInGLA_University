/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

//void display(char *);
//void display(string);
void display(char *s)
{
    cout << "Entered char array is: " << s << endl;
}

/*void display(string s)
{
    cout << "Entered string is: " << s << endl;
}*/

int main()
{
    //string str1;
    char str[100];

   // cout << "Enter a string: ";
  //  getline(cin, str1);

    cout << "Enter another string: ";
    cin>>str;

    //display(str1);
    display(str);
    return 0;
}


