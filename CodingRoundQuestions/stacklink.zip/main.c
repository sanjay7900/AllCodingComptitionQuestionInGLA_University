/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
#include<conio.h>

struct stack{
    int data;
    struct stack *add;
}*top=NULL;


void push_function(int);
int show_stack(struct stack*);
void pop();

int main()
{
   int i=1,a;
    //*top;
    //top=NULL;
   
   
    //cout<<"Hello World";
   push_function(12);
    push_function(123);
    push_function(124);
    push_function(15);
    push_function(11);
    show_stack(top);
    pop();
    pop();
    pop();
    pop();
    pop();
    printf("\n");
    //return 0;
    show_stack(top);
}




void push_function(int da)
{
    struct  stack *hold_element;
               //printf("<<enter: ");
               //scanf("%d",&a);
   hold_element=(struct stack*)malloc(sizeof(struct stack));
   
   hold_element->data=da;
   
  if(top == NULL)
    {
             hold_element->add=NULL;
             printf("<<now stack is ematy");
             top=hold_element;
     }

   else
     {
             hold_element->add=top;
             top=hold_element;
        
       }
   
    
}
int show_stack(struct stack *head)
{
    /*while(top!=NULL){
        printf("%d",top->data);
        top=top->add;
    }*/
    if(head==NULL){
        return 0;
    }
    else
    {
        
        show_stack(head->add);
        printf("%d  ",head->data);
        
    }
}
void pop(){
    struct stack *temp;
    if(top->add==NULL){
        printf("stack alraedy empty");
    }
    else{
    temp=top;
    top=top->add;
    printf("\n these items has been poped from stack %d \n",temp->data);
    free(temp);
    }
}





