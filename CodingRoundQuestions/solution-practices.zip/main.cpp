/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>

using namespace std;
class a;

class base
{
 int i;   
public:
    base(){
        cout<<"drived call"<<"\n";
        
    }
   virtual ~ base(){
    cout<<"drived des"<<"\n";
}
    
};

class a :public base{
    int i,k;
    public:
    a ()
    {
      /* i=l;
        k=m;
       cout<<i<<k;*/
       cout <<"base con"<<"\n";
        
    }
     ~ a(){
        cout<<"base des"<<"\n";
    }
    
};

int main()
{
    //cout<<"Hello World";
 // a a1(87,79);
  //b *b1 =new
 // base b1;
  a a2;
 a *a1= new a();
 base  *p=a1;
 delete p;
  //delete a1;
   // return 0;
}

