/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<bits/stdc++.h>
#include <iostream>

using namespace std;
#define ll long long
int main()
{
    //cout<<"Hello World";
    int n ;
    cin>>n;
    int mx=0;
    ll ans=0;
    for(int i=0;i<n;++i)
    {
        int x;
        cin>>x;
        mx=max(x,mx);
        cout<<"\n"<<mx<<"\n";
        ans=ans+mx-x;
        cout<<"nas="<<ans<<"\n";
        
    }
    cout<<"\n"<<ans;
    

    return 0;
}
