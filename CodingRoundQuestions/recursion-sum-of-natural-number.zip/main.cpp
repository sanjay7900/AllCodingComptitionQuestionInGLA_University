/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int sumof_natural(int n){
    if(n==0){
        return 0;
    }
    else{
        return n+sumof_natural(n-1);
    }
}

int main()
{ 
    int sum,d;
    d=10;
    cout<<"Hello World";
     sum=sumof_natural(d);
     cout<<sum;
     
    return 0;
}


