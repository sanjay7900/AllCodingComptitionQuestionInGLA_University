/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class s{
     int i;
     public:
     s(int a){
         i=a;
         
     }
    friend void operator+(s &b,int x);
     void dis(){
         cout<<endl<<i;
     }
};
void operator+(s &b,int x){
    b.i=b.i+x;
}

int main()
{ 
    
  
    s b1(5);
    b1.dis();
    b1+(2);
    b1.dis();

    return 0;
}
