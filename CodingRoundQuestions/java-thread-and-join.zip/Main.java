/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


*******************************************************************************/
import java.util.*;
class one extends Thread{
    one(String name){
        this.setName(name);
        
    }
    public void run(){
        for(int i=1;i<=200;i++){
            System.out.println("\n"+getName()+" "+ i);
        }
    }
}
class two extends Thread{
   two(String name){
        this.setName(name);
        
    }
    public void run(){
        for(int i=101;i<=100;i++){
            System.out.println("\n"+getName()+" "+ i);
        }
    }
}
class three extends Thread{
    three(String name){
        this.setName(name);
        
    }
    public void run(){
        for(int i=201;i<=300;i++){
            System.out.println("\n"+getName()+" "+ i);
        }
    }
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		try
		{
		    
		
		one a1=new one("thread one");
		a1.start();
		a1.join();
		two a2=new two("thread two");
		a2.start();
		a2.join();
		three a3=new three("thread three");
		a3.start();
		
		}
		catch(Exception e){
		    
		}
		
		
	}
}
