/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class Test {
    public:

int a; 
int b; 
virtual void fun (){}
Test(int templ = 0, int temp2 = 0)
{ a=templ;
b=temp2;
}

int getA() {

return a;
}

int getB() {
    return b;
}
};

int main()
{ 
    Test obj(5, 10);

  int* pInt = (int*)&obj;

*(pInt+0) = 100;

*(pInt+1) = 200;

cout << "a = " << obj.getA() << endl; cout << "b = " << obj.getB() << endl;
}
