/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std; 
  
void printFun(int test) 
{ 
    if (test < 1) 
        return; 
    else
    { 
       
       // cout << test << " "; 
        printFun(test-2);    // statement 2 
        cout << test << " "; 
        printFun(test-1);
        return; 
    } 
} 
  
int main() 
{ 
    int test = 20; 
    printFun(test); 
} 

