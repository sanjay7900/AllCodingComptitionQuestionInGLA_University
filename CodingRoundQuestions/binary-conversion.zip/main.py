'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
print ('Hello World')
def b_to_d_and_d_to_b_conversion(n):
    
    

    rem=0
    i=0
    decimal=0
    while n!=0:
        
        
        rem=n%10
        
        decimal=decimal+rem*pow(2,i)
        n=n//10
        #print(decimal)
        i=i+1
        
    return decimal    
        

def d(n):
    rem=0
    i=1
    binary=0
    while n!=0:
        rem=n%2
        n=n//2
        binary= binary+rem*i
        i=i*10
    return binary    
print( b_to_d_and_d_to_b_conversion(100011))
print(d(19))