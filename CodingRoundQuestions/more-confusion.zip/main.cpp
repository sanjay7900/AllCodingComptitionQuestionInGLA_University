/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class a;

class base
{
 int i;   
public:
    base(){
        cout<<"drived call";
        
    }
    ~ base(){
    cout<<"drived des";
}
    
};

class a{
    int i,k;
    public:
    a ()
    {
      /* i=l;
        k=m;
       cout<<i<<k;*/
       cout <<"base con";
        
    }
     ~ a(){
        cout<<"base des";
    }
    
};

int main()
{
    //cout<<"Hello World";
 // a a1(87,79);
  //b *b1 =new
 a b1();
  base a1();
  //delete a1;
   // return 0;
}
