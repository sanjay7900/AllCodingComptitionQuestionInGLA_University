'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class first_unique:
    temp=0
    
    
    
    def __init__(self,listpass):
        self.listget=listpass
        
        
        
        
    def add(self,number):
        self.listget.append(number)
        print(self.listget)
        
        
        
    def show_unique(self):
        for i in range(0,len(self.listget)):
            self.temp=0
            
            for j in range(0,len(self.listget)):
                
                if i==j:
                    pass
                else:
                    if self.listget[i]==self.listget[j]:
                        self.temp=-2
            if self.temp==0:
                
                print( self.listget[i])
                
            else:
                pass
                        
                        
                    
        
l=[2,3,5]    
a=first_unique(l) 
print(a.show_unique())
a.add(5)

print(a.show_unique())
a.add(3)
print(a.show_unique())
a.add(6)
print(a.show_unique())
print ('Hello World')

