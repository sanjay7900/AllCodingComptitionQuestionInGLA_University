/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int array(int arr[],int arrsize)
{
    int i=0,j,sum,check,no;
    
    for( j=1;j<arrsize;j++)
    {
         no=0;
         check=arr[j];
        if(arr[j]!=0)
        { 
            while(check!=0)
              {
               check=check/10;
                no++;
               }
                sum=arr[j-1];
         
            for(int k=0;k<no;k++)
             {
               sum=sum*10;
            
             }
        
            sum+=arr[j];
        
            arr[j]=sum;
        }
    
        else
        {
         arr[j]=arr[j-1]*10;
        }
    }
    cout<<arr[j-1];
}

int main()
{
   // cout<<"Hello World";
   int arr[]={0,9,0,0,1};
   array(arr,5);

    return 0;
}

