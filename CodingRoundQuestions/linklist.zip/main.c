/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node{
	int data;
	struct  node *add;
};
int dis(struct node *head){
    if(head==NULL){
    return 0;
}
else{
    dis(head->add);
    printf("%d  ",head->data);
}
}
int main(){
	int i=1;
	
	struct node *p,*start,*last;
	start=NULL;
	
	while(i==1){
		p=(struct node*)malloc(sizeof(struct node));
		printf("\nenter the data of node");
		scanf("%d",&p->data);
		if(start==NULL){
			start=p;
		    last=p;
		}
		else{
			last->add=p;
			last=p;
			last->add=NULL;
		}
		printf("\ndo you want to continue then press 1");
		scanf("%d",&i);
	}
	printf("now it is your data whatever you entered in linklist");
	last=start;
	p=start;
	
	
	while(last!=NULL)
	{
		printf("%d  ",last->data);
	    last=last->add;
		
	}
	printf("\n------------------------------------------\n");
	dis(start);
}
	

			
		
	
		
		


