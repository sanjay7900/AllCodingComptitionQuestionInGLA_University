/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
 void maximam_of_all_subarray(int arr[],int k,int size)
{
    int max=0;
    for(int i=0;i<=size-k;++i)
    {
        for (int j=i;j<i+k;++j)
        {
            if(arr[j]>max)
            {
                max=arr[j];
                
            }
        }
        cout<<max<<" ";
        max=0;
    }
    
}

int main()
{
    //cout<<"Hello World";
    int arr[]={10,2,3,4,6,53,89};
    maximam_of_all_subarray(arr,3,7);

    return 0;
}

