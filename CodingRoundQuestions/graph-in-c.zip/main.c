/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
struct graph{
    int data;
    struct graph *add;
    
};
//struct graph *adj[5];
void make_graph(struct graph* adj[], int no_of_node)
{
    int i,n;
    struct graph *last=NULL;
    
    for(i=0;i<no_of_node;++i)
    {
       printf("enter the neighbour\n");
       scanf("%d",&n);
       for(int j=0;j<n;++j)
       {
           struct graph *ne;
           ne=(struct graph*)malloc(sizeof(struct graph*));
           printf("enter the value of nade\n");
           int value;
           scanf("%d",&value);
           ne->data=value;
           ne->add=NULL;
           if(adj[i]==NULL)
           {
              adj[i]=ne;
              last=ne;
            
            }
           else
            {
              last->add=ne;
              last=ne;
            }
        
        }
    }
   // return adj;
}
void print(struct graph *adj[], int size)

{
    struct graph *ptr;
    for(int i=0;i<size;++i)
    {
        ptr=adj[i];
        printf("\nprint the neighbour node of%d\n",i+1);
        while(ptr!=NULL)
        {
            printf("\n%d",ptr->data);
            ptr=ptr->add;
        }
    }
}

int main()
{ 
    struct graph *adj[5];
    for(int i=0;i<5;++i){
        adj[i]=NULL;
    }
    make_graph(adj,4);
    print(adj,5);

    return 0;
}


