/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class arraylist{
    
       ArrayList li=new ArrayList();
    
    void add_arrlist(int item)
    {
        li.add(item);
    }
     void add_arrlist(String item)
    {
        li.add(item);
    }
     void add_arrlist(double item)
    {
        li.add(item);
    }
    void dis()
    {
        Iterator it=li.iterator();
        while(it.hasNext())
        {
            System.out.println(it.next());
        }
    }
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		arraylist l1=new arraylist();
		l1.add_arrlist(12);
		l1.add_arrlist(12);
		l1.add_arrlist("sanjay");
		l1.add_arrlist(29.00);
		l1.li.add("rahul");
		l1.dis();
	}
}

