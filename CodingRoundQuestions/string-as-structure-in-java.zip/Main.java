/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
     public static void main(String[] args) {
	  String name[] = new String[10];
	  Scanner myObj = new Scanner(System.in);
	 int age[] = new int[10];
	 int salary[] = new int[10];
	  
	  
	  for(int i=0;i<10;i++){
          System.out.println("Enter name, age and salary:");
        name[i] = myObj.next();

    // Numerical input
     age[i] = myObj.nextInt();
     salary[i] = myObj.nextInt();
	  }
  

    // Output input by user
		for(int i=0;i<10;i++){

    System.out.println("Name: " + name[i]);
    System.out.println("Age: " + age[i]);
    System.out.println("Salary: " + salary[i]);
  }
  }
    
}



