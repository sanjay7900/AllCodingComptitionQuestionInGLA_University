'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
print ('Hello World')
def find(l):
    d=[]
    for i in l:
        k=i[0]
        for j in l:
            if j==i:
                pass
            else:
                if j[0]==k:
                    if j not in d:
                        d.append(j)
                        print(j)
    print(d)                
mylist = ["hello","horld","how","pou","doing"]
find(mylist)