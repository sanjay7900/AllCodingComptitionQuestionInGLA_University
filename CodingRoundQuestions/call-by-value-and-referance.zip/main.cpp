/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int sum(int *a,int *b){
    *a=*a+10;
    *b=*b+10;
}

int main()
{
    int a=10,b=10;
    cout<<"Hello World";
     cout<<a<<endl;
     cout<<b<<endl;
     sum(&a,&b);
     cout<<a<<endl;
     cout<<b<<endl;
    return 0;
}
