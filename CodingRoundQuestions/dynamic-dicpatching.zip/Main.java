/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


*******************************************************************************/
import java.util .*;
class simple_interest{
    double interest;
    void cal_interest(double rate,double pr,double time){
      interest=(time*pr*rate)/100;
      System.out.println("simle interest ="+interest);
    }
}
class compound_interest extends simple_interest{
    double compound_int;
    void cal_interest(double rate,double pr,double time){
        compound_int=pr * Math.pow(1.0+rate/100.0,time) - pr;
        System.out.println("compound interest ="+compound_int);
        
    }
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		simple_interest s1=new simple_interest();
		s1.cal_interest(10,10,10);
		compound_interest s2=new compound_interest();
		s2.cal_interest(10,10,10);
	}
}

