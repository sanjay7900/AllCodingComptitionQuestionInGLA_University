/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class unique_item
{
    
    int n,i,j,k=0;
    void sanjay()
{
    Scanner sc= new Scanner(System.in);
    System.out.println("enter the size of Array :");
    n=sc.nextInt();
    int[] arr=new int[n];
    int[] unique=new int[n];
     System.out.println("enter the element of Array \n:");
    for(i=0;i<n;i++)
    {
        arr[i]=sc.nextInt();
        
    }
    System.out.print("[");
    for(i=0;i<n;i++)
    {
        System.out.print(arr[i]);
        
    }
    System.out.print("]");
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
           if(i!=j)
           {
               if(arr[i]==arr[j])
               {
                   k=-1;
               }
           }
        }
        
        if(k==0)
        {
            unique[i]=arr[i];
        }
        k=0;
        
    }
    System.out.println("now it is uniqe items\n[");
    for(i=0;i<n;i++)
    {
        System.out.print(unique[i]);
        
    }
    
    
}  
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		unique_item a1=new unique_item();
		a1.sanjay();
	}
}
