/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
fun(int a){
    a++;
    
}

int main()
{
    //printf("Hello World");
    // fun();
     //fun();
     int a;
     //a='a'>'A';
     //printf("%d");
     int b;
     for(a=b=10;a;printf("\t%d\t%d\t%d",a,b))
     a=b++<=1;
     printf("\t%d\t%d",a+10,b+10);
     
    return 0;
}
