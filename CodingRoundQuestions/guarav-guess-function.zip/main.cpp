/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
void guess_function(int number)
{   
    int i=1,your_number;

    while(i!=9)
    {
        cout<<"\nGussse  your number: ";
        cin>>your_number;
        if(number==your_number)
        {
            cout<<"\nyour attempt is successful in   "<<i<<"   time";
            cout<<"\n"<<"your_number  =  computer random number  "<<your_number<<"  =  "<<number;
            break;
            
        }
        else
        {
            cout<<"\nyour attempt fails   "<<i<<"   times";
            cout<<"\nyou have only   "<<9-i<<"  chance";
            
        }
        
        
        
        i++;
        
        
    }
    
}

int main()
{
    cout<<"Hello World";
    int n=15;
    guess_function(n);

    return 0;
}
