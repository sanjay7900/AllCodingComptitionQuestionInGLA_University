/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

int main()
{
/*{
    char name[5][10];
    int i,j;
    cout<<"Hello World"<<"\n";
    for(i=0;i<5;i++){
        for(j=0;j<10;j++){
            cin>>name[i][j];
        }
    }
    
// for(i=0;i<5;i++){
        for(j=0;j<10;j++){
            cout<<name[i][j];
        }
        cout<<"\n";
    }*/
    int i,count;
    char hold;
    char name[10];
    cin>>name;
    for(i=0;i<10;i++){
    
    cout<<"\n"<<name[i];
    hold=name[i];
    if(hold=='a'|| hold=='i'|| hold=='u'|| hold=='o'||hold=='e'){
        count++;
    }
    
    }
    cout<<"\nthese are vowels in this string ="<<count;
    
    return 0;
}
