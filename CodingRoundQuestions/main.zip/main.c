/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int sum(int a){
    if(a>0){
    return  (a+sum(a-2));
   // return b;
    }
}

int main()
{
    printf("Hello World");
   //main();
   printf("%d",sum(10));
   
    return 0;
}
