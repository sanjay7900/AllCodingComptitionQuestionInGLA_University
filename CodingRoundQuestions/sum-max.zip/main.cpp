/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
void max_array(int arr[],int l,int max)
{
    int i,j,k=max;
    int n=l;
    
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(sum==max){
                cout<<
            }
        }
    }
}

int main()
{ int l,i,m=30;
    cout<<"Hello World";
    cout<<"enter the size of array";
    cin>>l;
    
     int array[l];
     cout<<"enter the array element";
     for(i=0;i<l;i++){
         cin>>array[i];
     }
     max_array(array,l,m);
    return 0;
}
