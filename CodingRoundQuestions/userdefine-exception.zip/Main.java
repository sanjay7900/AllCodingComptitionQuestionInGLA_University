/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 class user_define_exception extends Exception{
      user_define_exception(String s){
         super(s);
     }
     
 }
 class myexception{
     void ex()throws user_define_exception{
         int a = 0;
         try
         {
             if(a==0)
                {
                 throw new user_define_exception("your value should be greater than 0 ok thank you...");
                }
         }
        catch(Exception e)
                {
                 System.out.println(e);
                }
         
     }   
 }
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		try{
		myexception a1=new myexception();
		a1.ex();
		}
		catch(Exception e){
		    
		
		
		    System.out.println(e);
		}
		
	}
}
