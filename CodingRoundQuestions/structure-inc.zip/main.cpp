/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
#include<string.h>
struct Person
{
    char name[50];
    int age;
    float salary;
};

int main()
{ 
    int i;
    Person p1[5];
    for(i=0;i<5;i++){
    cout<<"Enter Full name: ";
    cin>>p1[i].name;
    cout<<"Enter age: ";
    cin>>p1[i].age;
    cout<<"Enter salary: ";
    cin>>p1[i].salary;
}
for(i=0;i<5;i++){
    cout << "\nDisplaying Information." << endl;
    cout << "Name: " << p1[i].name << endl;
    cout <<"Age: " << p1[i].age << endl;
    cout << "Salary: " << p1[i].salary;
}
    return 0;
}

