/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
// this function  will be make sum of  even digit and odd digit
int sanjay(int a){
    if(a>1){
        //printf("%d",a);
        return a+sanjay(a-2);
        
    }
}
int swap(int *a, int *b){
    *a=*a+*b;
    *b=*a-*b;
    *a=*a-*b;
}

int main()
{
    printf("Hello World");
  int a=10;
  if(a%2==0){
  printf("%d",sanjay(a-1));
  }
  else{
      
  }
  int x=10,y=20;
  swap(&x,&y);
  printf("%d%d",x,y);
    return 0;
}
