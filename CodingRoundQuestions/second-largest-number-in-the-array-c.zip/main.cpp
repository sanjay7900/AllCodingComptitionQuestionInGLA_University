/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int second_largest_number(int arr[], int size)
{
    int  i,max=0, second_max=0;
    if(size==0)
    {
        return 0;
    }
    else
    {
        
    
         for(i=0;i<size;i++)
          {
               if(max<arr[i])
               {
                   max=arr[i];
            
                }
    
    
                if(arr[i]>=second_max && second_max<max)
                 {
                      second_max=arr[i];
                 }
           }
        return second_max;
    }
    
}

int main()
{
    cout<<"Hello World";
    int arr[]={1,2,3,4,5,6,7,9,23,24};
   int s, size=9;
    s=second_largest_number(arr,size);
    cout<<"\n this is second largest number in this array : "<<s;
    

    return 0;
}

