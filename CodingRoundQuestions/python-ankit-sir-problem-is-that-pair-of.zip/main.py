'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def fun(l,n):
    #print("enter the limit ")
    #n=int(input("enter the n"))
    for i in range(0,n):
        a=int(input("enter the your number"))
        l.append(a)
        
    return l

def mainwork(m,n):
    l1=fun(l,n)
    ll=[]
    l2=[]
    final=[]
    for i in range(0,((n-m)+1)):
        for j in range(i,i+m):
            l2.append(l1[j])
            
        ll.append(l2)
        l2=[]
        
    print(ll) 
    for i in ll:
        i.sort()
        k=max(i)-min(i)
        final.append(k)
    print(final)
    

l=[]
n=5
m=4
mainwork(m,n)
#print(fun(l))
    

