/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int fib(int n)
{
    if(n==1 )
    {
        return 1;
    }
    else if(n==0)
    {
        return 0;
    }
    else
    {
        return fib(n-1)+fib(n-2);
    }
}

int main()
{
    printf("Hello World");
    int n=10;
    for(int i=0;i<n;i++)
    {
        printf("\n%d",fib(i));
    }

    return 0;
}
