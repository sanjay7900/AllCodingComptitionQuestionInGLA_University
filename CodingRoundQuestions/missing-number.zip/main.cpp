/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int missing_number(int size){
    int sum;
    for(int i=0;i<size;++i){
        int enter_number;
        cin>>enter_number;
        sum+=enter_number;
        
        
    }
    int m=((size*(size+1))/2);
      unsigned int r=((size*(size+1))/2)-sum;
      //sum+=r;
      cout<<"\n"<<sum<<"\n";
      if(sum%m==0)
      {
         // cout<<sum/m;
      }
      else{
        //  cout<<sum%m;
      }
      
     
    
}

int main()
{
    cout<<"Hello World";
    int n;
    n=5;
   /* cout<<"\n"<<"this is the missing number in arrry \n = "<<*/missing_number(n);
    

    return 0;
}


