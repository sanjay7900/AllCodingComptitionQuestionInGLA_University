/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class validation extends Exception{
    validation(String s){
        super(s);
    }
}

class create_array{
      
    
       static void make_array()throws validation{
          
           Scanner sc = new Scanner(System.in);
       
        try{
             System.out.println("ente the size of array");
             int size = Integer.parseInt(sc.nextLine());
            //int size =-1;
           if(size<0){
               throw new validation ("negative size of array");
               }
               
               
          else{
             int arr[]=new int[size];
             System.out.println("array has been created of this size"+size);

            }
        }
        /*catch(NumberFormatException e){
            System.out.println(e);
        }*/
        catch(Exception m){
            System.out.println(m);
        }
        
        
        
    } 
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		try{
		create_array a1=new create_array();
		a1.make_array();
		}
		catch(Exception e){
		    System.out.println(e);
		}
	}
}

