/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class string_check
{
    void check_cammon_logest_string(String s1,String s2)
    {
        int i,j,k ,max_length=0;
        
        String ch1,ch2,cammon_string="";
        
        for(i=0;i<s1.length();i++)
        {
              ch1=s1.substring(i,s1.length());
              
            for(j=0;j<s2.length();j++)
            {
                ch2=s2.substring(j,s2.length());
                 //System.out.println("\n"+ch1+"\n"+ch2);
                if(ch1.equals(ch2))
                {
                    if(max_length<ch1.length())
                    {
                        max_length=ch1.length();
                        
                        cammon_string=ch1;
                        //System.out.println("\n"+ch1);
                    }
                    
                }
                 
                
            }
        }
        System.out.println("\n"+cammon_string);
    }
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		string_check a1=new string_check();
		a1.check_cammon_logest_string("sanjay singh", "jnkjc sanjy singh");
	}
}

