/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
using namespace std;
struct linklist{
    int data;
    struct linklist *add;
};
struct linklist *start=NULL,*last;
int find_maximam_data_in_linklist( struct linklist *head){
    
    int i=0;
    while(head!=NULL){
        if(head->data>i){
            i=head->data;
        }
        head=head->add;
        //find_maximam_data_in_linklist(head->add);
    }
   return i; 
  /*  if(head==NULL){
       return 0; 
    }
    else{
        if(head->data<head->add->add){
            head->data=head
        }
        
       
    }*/
       
}
void reverse_display( struct linklist *head){
    if(head==NULL){
        return;
    }
    else{
        
        reverse_display(head->add);
        std::cout << head->data<< std::endl;
    }
    
}
void createnode(int item){
    
    struct linklist *p;
    p=(struct linklist*)malloc(sizeof(struct linklist));
    p->data=item;
    if(start==NULL){
        start=p;
        last=p;
        
    }
    else{
        last->add=p;
        last=p;
        
    }
}
void addAnodeatposition(struct linklist *head,int p,int item){
    int i=1;
    struct linklist *l,*po;
    if(head==NULL){
        cout<<"no any node";
        
    }
    else{
        po=(struct linklist*)malloc(sizeof(struct linklist));
        po->data=item;
        while(i!=p){
            head=head->add;
           i++;
            }
    }
    l=head->add;
    head->add=po;
    po->add=l;
    cout<<"\n"<<head->data;
}

int main()
{
    int a=1,i,j,choice,t,position;
    createnode(20);
    createnode(23);
    createnode(89);
    createnode(90);
    createnode(679);
    //reverse_display(start);
    //cout<<"\n"<<find_maximam_data_in_linklist(start);
    //addAnodeatposition(start,3,333);
   // reverse_display(start);
    while(a!=0){
        cout<<"\n"<<"-------------------";
        cout<<"\n"<<"enter 1 for the gentare a node";     
        cout<<"\n"<<"enter 2 for  add a node at spacesific postion";
        cout<<"\n"<<"enter 3 for the maximam elment";
        cout<<"\n"<<"enter 4 for the display";
        cout<<"\n"<<"enter for exit";
        cout<<"----------------------------------";
        cin>>choice;
        switch(choice)
        {
            case 1:
            {
                cout<<"\n"<<"enter the value for the node";
                cin>>t;
                createnode(t);
                cout<<"\n";

                break;
            }
            case 2:
            {
                cout<<"\n"<<"enter the value for the node";
                cin>>t;
                cout<<"\n"<<"enter the position for the node";
                cin>>position;
                addAnodeatposition(start,position,t);
                cout<<"\n";

                break;
                
            }
            case 3:
            {
                find_maximam_data_in_linklist(start);
                cout<<"\n";
                break;
                
            }
            case 4:
            {
              reverse_display(start);
              break;
            }
            default:
            {
                cout<<"\n"<<" invalid choice";
            }
        }



        
        
    }
   
}





