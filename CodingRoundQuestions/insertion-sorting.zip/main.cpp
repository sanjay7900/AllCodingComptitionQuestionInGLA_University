/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int a[100],i,j,k,temp;
    cout<<"\n"<<"enter the std::array>" ;
    cin>>k;
    for(i=0;i<k;i++){
        cin>>a[i];
    }
    for(i=0;i<k;i++){
        for(j=i+1;j<k;j++){
            if(a[i]>a[j]){
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
    for(i=0;i<k;i++){
        cout<<a[i]<<" ";
    }
    cout<<"Hello World";

    return 0;
}
