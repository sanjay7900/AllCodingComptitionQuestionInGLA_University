'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
print ('Hello World')
a=int(input("entr the number: "))
r=a%10;
d=a//10;
if r==d:
    print("number is this",(10*d)+r)
    
    
else:
    print("number is this",(10*d)+r)
    